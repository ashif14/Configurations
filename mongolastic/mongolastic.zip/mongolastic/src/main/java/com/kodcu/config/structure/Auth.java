package com.kodcu.config.structure;

/**
 * Created by Hakan on 5/14/2016.
 */
public class Auth {

    private String user;
    private String pwd;
    private String source;
    private String mechanism;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getMechanism() {
        return mechanism;
    }

    public void setMechanism(String mechanism) {
        this.mechanism = mechanism;
    }

    @Override
    public String toString() {
        return "Auth [user=" + user + ", pwd=" + pwd + ", source=" + source + ", mechanism=" + mechanism + "]";
    }

}
